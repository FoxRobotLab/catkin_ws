
from Myro import *
import SubsumptionBrain


class Circle(SubsumptionBrain.SubsumptionBehavior):

    def update(self):
        """This behavior ignores sensors, and just goes in a slow circle"""
        self.setSpeeds(0.5, 0.7)
        self.setFlag()

        

# -----------------------------------------------------
# Run the demo using something like this:


def runDemo(time = 120):
    """This function is really a model to be modified.  It shows how to take a SubsumptionBrain
    and an optional time, add behaviors to the brain, and then run it for the given time."""
    brain = setupSubsumption()
    # add behaviors, in order from lowest to hightest
    brain.add( Circle() )

    for t in timer(time):
        brain.step()
    brain.stopAll()


                   
def setupSubsumption(robotCode = None):
    """Helpful function takes optional robot code (the six-digit Fluke board number). If code
    is given, then this connects to the robot. Otherwise, it connects to a simulated robot, and
    then creates a SubsumptionBrain object and returns it."""
    if robotCode == None:
        sim = getSimulation()
        if sim == None:
            # No simulation running, make one
            init('sim')
            sim = getSimulation()
        currRobot = sim.robots[0]
    else:
        serialPort = "/dev/tty.IPRE6-" + robotCode + "-DevB"
        currRobot = makeRobot("Scribbler", serialPort)
    currBrain = SubsumptionBrain.SubsumptionBrain(currRobot)
    return currBrain

